﻿//Gender.cs

namespace L1
{

    /// <summary>
    /// Represents the Gender of an employee.
    /// </summary>
    internal enum Gender
    {
        // Male Gender
        M,

        // Female Gender
        F
    }
}
